"""Install the shared Xpull writer for the current macOS Chrome user."""
import json
from pathlib import Path
import re
import shlex
import shutil
import struct
import subprocess
import sys


def register(home, extension, python, worker):
    launcher = worker.with_name("launch-writer")
    launcher.write_text(
        "#!/bin/sh\nexec " + shlex.join([str(python), "-B", "-X", "utf8", str(worker)]) + "\n",
        encoding="utf-8",
    )
    launcher.chmod(0o700)
    hosts = home / "Library/Application Support/Google/Chrome/NativeMessagingHosts"
    hosts.mkdir(parents=True, exist_ok=True)
    name = "studio.aigx.xpull"
    manifest = {"name": name, "description": "Xpull local video editor", "path": str(launcher),
                "type": "stdio", "allowed_origins": [f"chrome-extension://{extension}/"]}
    (hosts / (name + ".json")).write_text(json.dumps(manifest, indent=2), encoding="utf-8")


def main():
    if sys.platform != "darwin" or sys.version_info < (3, 9):
        sys.exit("请在 Mac 上使用 Python 3.9 或更新版本运行。")
    extension = input("粘贴 chrome://extensions 中现有 Xpull 扩展的 ID：").strip()
    if not re.fullmatch("[a-p]{32}", extension):
        sys.exit("扩展 ID 应为 32 个 a–p 小写字母。")
    ollama = shutil.which("ollama") or "/Applications/Ollama.app/Contents/Resources/ollama"
    if not Path(ollama).is_file():
        sys.exit("请先安装并打开 Ollama，再运行此安装程序。")
    subprocess.run([ollama, "list"], check=True)
    if subprocess.run([ollama, "show", "xpull-aigx:4b"], capture_output=True).returncode:
        subprocess.run([ollama, "pull", "gemma3:4b"], check=True)
    target = Path.home() / "Library/Application Support/Xpull/aigx"
    target.mkdir(parents=True, exist_ok=True)
    env = target / "venv"
    subprocess.run([sys.executable, "-m", "venv", str(env)], check=True)
    python = env / "bin/python"
    subprocess.run([str(python), "-m", "pip", "install", "opencv-python", "Pillow"], check=True)
    worker = target / "writer.py"
    shutil.copyfile(Path(__file__).with_name("writer.py"), worker)
    request = b'{"action":"check"}'
    reply = subprocess.run([str(python), str(worker)], input=struct.pack("<I", len(request)) + request,
                           stdout=subprocess.PIPE, check=True).stdout
    length, = struct.unpack("<I", reply[:4])
    if len(reply) != 4 + length:
        sys.exit("本机写作服务返回了不完整的响应。")
    result = json.loads(reply[4:])
    if not result.get("ok"):
        sys.exit("模型检查失败：" + result["message"])
    register(Path.home(), extension, python, worker)
    print("写作服务已就绪。保持 Ollama 运行，回到原采集台点击「补写待处理文案」。")


if __name__ == "__main__":
    main()
