import {mkdirSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';

const [python, extension='dpflegnflgfkbagjnfigahjajmbomeii']=process.argv.slice(2);
if(process.platform!=='win32' || !python || !path.isAbsolute(python) || !/^[a-p]{32}$/.test(extension)){
  throw new Error('用法：node aigx/install.mjs <python.exe 绝对路径> [Chrome 扩展 ID]');
}
execFileSync(python,['-c','import cv2; from PIL import Image']);
const target=path.join(process.env.LOCALAPPDATA,'Xpull','aigx');
mkdirSync(target,{recursive:true});
const launcher=path.join(target,'writer.cmd');
const worker=fileURLToPath(new URL('./writer.py',import.meta.url));
writeFileSync(launcher,'@echo off\r\n"'+python+'" -B -X utf8 "'+worker+'"\r\n');
const manifest=path.join(target,'host.json');
writeFileSync(manifest,JSON.stringify({name:'studio.aigx.xpull',description:'Xpull local video editor',
  path:launcher,type:'stdio',allowed_origins:['chrome-extension://'+extension+'/']},null,2));
for(const browser of ['Google\\Chrome','Microsoft\\Edge']){
  execFileSync('reg.exe',['add','HKCU\\Software\\'+browser+'\\NativeMessagingHosts\\studio.aigx.xpull','/ve','/t','REG_SZ','/d',manifest,'/f']);
}
console.log('已为本机浏览器注册 AIGX 写作服务：'+manifest);
