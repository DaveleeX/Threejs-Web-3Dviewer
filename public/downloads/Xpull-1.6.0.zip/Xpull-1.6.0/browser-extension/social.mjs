const headers={
  title:/^(笔记标题|笔记名称|标题|作品名称|作品标题|笔记内容|正文|内容|title|text)$/i,
  category:/^(笔记类型|内容类型|类型|分类|赛道|垂类|category|type)$/i,
  rank:/^(排名|名次|排行|rank)$/i,
  likes:/^(点赞(数|量)?|获赞(数|量)?|喜欢|likes?)$/i,
  comments:/^(评论(数|量)?|comments?)$/i,
  saves:/^(收藏(数|量)?|saves?)$/i,
  shares:/^(分享(数|量)?|转发(数|量)?|shares?)$/i,
  total:/^(总?互动(数|量)?|互动总量|engagements?)$/i
};

function number(value){
  const m=String(value??'').replace(/[,，\s]/g,'').match(/^(\d+(?:\.\d+)?)(万|亿|[kwm])?\+?$/i);
  return m?Number(m[1])*({万:1e4,亿:1e8,k:1e3,w:1e4,m:1e6}[m[2]?.toLowerCase()]||1):null;
}

function tableRows(table){
  for(let i=0;i<table.length;i++){
    const columns=Object.fromEntries(Object.entries(headers).map(([key,re])=>[key,table[i].findIndex(cell=>re.test(cell.trim()))]));
    if(columns.title<0 && columns.category<0) continue;
    return table.slice(i+1).flatMap(row=>{
      const field=k=>(row[columns[k]]||'').trim();
      const title=field('title'), category=field('category');
      if(!title && !category) return [];
      const metrics=['likes','comments','saves','shares'].map(k=>number(field(k))).filter(v=>v!==null);
      return [{title,category,rank:number(field('rank')),score:number(field('total'))??(metrics.length?metrics.reduce((a,b)=>a+b):null)}];
    });
  }
  return [];
}

function csv(text){
  const sep=text.split(/\r?\n/,1)[0].includes('\t')?'\t':',';
  const rows=[]; let row=[], value='', quoted=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(c==='"'){
      if(quoted && text[i+1]==='"'){value+='"';i++;}else quoted=!quoted;
    }else if(!quoted && c===sep){row.push(value);value='';}
    else if(!quoted && c==='\n'){row.push(value.trimEnd());rows.push(row);row=[];value='';}
    else value+=c;
  }
  if(quoted) throw Error('CSV 的引号不完整');
  row.push(value.trimEnd()); rows.push(row); return rows;
}

// Office Open XML stores worksheets and document text as ZIP members.
function office(buffer){
  const view=new DataView(buffer), bytes=new Uint8Array(buffer), decoder=new TextDecoder();
  let end=bytes.length-22;
  while(end>=Math.max(0,bytes.length-65557) && view.getUint32(end,true)!==0x06054b50) end--;
  if(end<0 || end<bytes.length-65557) throw Error('无法读取 Office 文件，请另存为未加密的 .xlsx 或 .docx');
  const entries=new Map();
  let pos=view.getUint32(end+16,true), budget=32*1024*1024;
  for(let i=0;i<view.getUint16(end+10,true);i++){
    if(view.getUint32(pos,true)!==0x02014b50) throw Error('文件目录损坏');
    const n=view.getUint16(pos+28,true);
    entries.set(decoder.decode(bytes.subarray(pos+46,pos+46+n)),pos);
    pos+=46+n+view.getUint16(pos+30,true)+view.getUint16(pos+32,true);
  }
  async function xml(name){
    const p=entries.get(name), local=view.getUint32(p+42,true);
    const start=local+30+view.getUint16(local+26,true)+view.getUint16(local+28,true);
    const packed=bytes.subarray(start,start+view.getUint32(p+20,true));
    const method=view.getUint16(p+10,true);
    if(view.getUint32(p+24,true)>budget || ![0,8].includes(method)) throw Error('文档过大或压缩格式不支持');
    let stream=new Blob([packed]).stream();
    if(method===8) stream=stream.pipeThrough(new DecompressionStream('deflate-raw'));
    const chunks=[];
    for await(const chunk of stream){budget-=chunk.length;if(budget<0) throw Error('解压后的文档过大');chunks.push(chunk);}
    const doc=new DOMParser().parseFromString(await new Blob(chunks).text(),'application/xml');
    if(doc.querySelector('parsererror')) throw Error('文档结构损坏');
    return doc;
  }
  return {entries,xml};
}

const nodes=(e,name)=>Array.from(e.getElementsByTagNameNS('*',name));
const content=e=>nodes(e,'t').map(t=>t.textContent).join('');

export async function readLinkFile(file){
  if(file.size>12*1024*1024) throw Error('请选择不超过 12 MB 的文件。');
  const ext=file.name.split('.').pop().toLowerCase(), buffer=await file.arrayBuffer();
  if(['txt','md','csv'].includes(ext)){
    const bytes=new Uint8Array(buffer);
    if(bytes[0]===255 && bytes[1]===254) return new TextDecoder('utf-16le').decode(buffer);
    if(bytes[0]===254 && bytes[1]===255) return new TextDecoder('utf-16be').decode(buffer);
    try{return new TextDecoder('utf-8',{fatal:true}).decode(buffer);}catch{return new TextDecoder('gb18030').decode(buffer);}
  }
  if(ext!=='docx') throw Error('请选择 TXT、Markdown、CSV 或 DOCX 文件；旧版 Word 请先另存为 .docx。');
  const {entries,xml}=office(buffer);
  if(!entries.has('word/document.xml')) throw Error('未找到 Word 正文。');
  const doc=await xml('word/document.xml');
  const paragraphs=nodes(doc,'p').map(content);
  const rel='word/_rels/document.xml.rels';
  if(entries.has(rel)){
    const used=new Set(nodes(doc,'hyperlink').map(h=>Array.from(h.attributes).find(a=>a.localName==='id')?.value));
    for(const r of nodes(await xml(rel),'Relationship')){
      if(used.has(r.getAttribute('Id')) && r.getAttribute('Type')?.endsWith('/hyperlink')) paragraphs.push(r.getAttribute('Target'));
    }
  }
  paragraphs.push(...nodes(doc,'instrText').map(n=>n.textContent));
  return paragraphs.join('\n');
}

export async function analyzeFile(file){
  if(file.size>12*1024*1024) throw Error('请选择小于 12 MB 的文件');
  const ext=file.name.split('.').pop().toLowerCase(), buf=await file.arrayBuffer();
  let rows=[];
  if(ext==='csv'){
    let text;
    try{text=new TextDecoder('utf-8',{fatal:true}).decode(buf);}catch{text=new TextDecoder('gb18030').decode(buf);}
    rows=tableRows(csv(text));
  }else if(ext==='xlsx' || ext==='docx'){
    const {entries,xml}=office(buf);
    if(ext==='xlsx'){
      const strings=entries.has('xl/sharedStrings.xml')?nodes(await xml('xl/sharedStrings.xml'),'si').map(content):[];
      for(const name of entries.keys()){
        if(!/^xl\/worksheets\/[^/]+\.xml$/.test(name)) continue;
        const table=nodes(await xml(name),'row').map(r=>{
          const cells=[];
          for(const c of nodes(r,'c')){
            const letters=c.getAttribute('r')?.match(/^[A-Z]+/)?.[0];
            const col=letters?[...letters].reduce((n,l)=>26*n+l.charCodeAt(0)-64,0)-1:cells.length;
            const v=nodes(c,'v')[0]?.textContent||'';
            if(col>=0 && col<16384) cells[col]=c.getAttribute('t')==='s'?strings[Number(v)]||'':content(c)||v;
          }
          return Array.from(cells,s=>s||'');
        });
        rows.push(...tableRows(table));
      }
    }else{
      if(!entries.has('word/document.xml')) throw Error('未找到 Word 正文');
      const doc=await xml('word/document.xml');
      for(const tbl of nodes(doc,'tbl')) rows.push(...tableRows(nodes(tbl,'tr').map(r=>nodes(r,'tc').map(content))));
      if(!rows.length){
        for(const p of nodes(doc,'p')){
          const text=content(p).trim();
          const m=text.match(/^(?:第\s*)?(\d+)(?:\s*名|[.．、)）:：])\s*(.+)$/);
          if(m) rows.push({rank:Number(m[1]),title:m[2]});
          else if(text && nodes(p,'numPr').length) rows.push({rank:rows.length+1,title:text});
        }
      }
    }
  }else throw Error('支持 .xlsx、.csv、.docx，请先转换旧格式');
  const ranked=rows.some(r=>r.rank>0);
  const sorted=rows.filter(r=>ranked?r.rank>0:r.score!=null).sort((a,b)=>ranked?a.rank-b.rank:b.score-a.score);
  const seen=new Set(), posts=[];
  for(const r of sorted){
    const key=(r.title||r.category).toLowerCase();
    if(seen.has(key)) continue;
    seen.add(key); posts.push({...r,text:[r.category,r.title].filter(Boolean).join(' ')});
    if(posts.length===10) break;
  }
  if(!posts.length) throw Error('需要标题或类型，以及排名或互动数据；Word 也可用编号榜单，如「1、动画与动捕」');
  return {posts,method:ranked?'按排名':'按互动总量'};
}
