const ignored = new Set('the and this that for with from are was you your have about just video watch today how via out new 视频 分享 一个 这个 我们 他们 可以 今天 就是 了 的'.split(' '));
const segmenter = new Intl.Segmenter('zh', { granularity: 'word' });

export function topics(posts) {
  const weights = new Map();
  for (const post of posts) {
    const words = new Map();
    const clean = post.text.replace(/https?:\/\/\S+|@[\w_]+/gu, ' ').toLowerCase();
    for (const {segment, isWordLike} of segmenter.segment(clean)) {
      if (isWordLike && /^[\p{L}][\p{L}\p{N}_]{1,29}$/u.test(segment) && !ignored.has(segment)) words.set(segment, 1);
    }
    for (const {tag} of post.entities?.hashtags || []) {
      if (/^[\p{L}\p{N}_]{1,30}$/u.test(tag)) words.set(tag.toLowerCase(), 4);
    }
    for (const [word, weight] of words) weights.set(word, weight + (weights.get(word) || 0));
  }
  return [...weights].sort((a,b) => b[1]-a[1]).slice(0,6).map(([word]) => word);
}

export function quality(variant) {
  const match = new URL(variant.url).pathname.match(/\/(\d{2,5})x(\d{2,5})\//);
  return {pixels: match ? Number(match[1])*Number(match[2]) : 0, label: match ? match[1]+' × '+match[2] : 'MP4'};
}

export function selectVideo(media) {
  const mp4 = (media.variants || []).filter(v => v.content_type === 'video/mp4' && /^https:\/\/video\.twimg\.com\//i.test(v.url));
  return mp4.sort((a,b) => quality(b).pixels-quality(a).pixels || (b.bit_rate || b.bitrate || 0)-(a.bit_rate || a.bitrate || 0))[0];
}
export function recentSample(feeds, limit = 20) {
  const posts = new Map();
  for (let index = 0; feeds.some(feed => index < feed.length); index++) {
    for (const feed of feeds) {
      const post = feed[index];
      if (post && !posts.has(post.id)) posts.set(post.id, post);
      if (posts.size === limit) return posts;
    }
  }
  return posts;
}

