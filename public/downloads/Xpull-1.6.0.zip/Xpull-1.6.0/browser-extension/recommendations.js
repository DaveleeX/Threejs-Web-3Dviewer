// Listen only in tabs opened for a specific Xpull task.
(() => {
  const directId=location.hash==='#xpull-post' && location.pathname.match(/\/status\/(\d+)\/?$/)?.[1];
  if (!directId && (location.pathname !== '/home' || (location.hash !== '#xpull' && !window.__xpullActiveRun))) return;
  if(window.__xpullRecommended || window.__xpullDirectPost) return;
  const rows = new Map();
  const samples = new Map();
  let pages=0;
  function accept(data){
    pages++;
    ingest(data);
  }
  window.__xpullFeedPages=()=>pages;
  const isSearch = url => {
    try {
      const u = new URL(url,location.href);
      const route=directId ? /\/(TweetDetail|TweetResultByRestId)\/?$/ : /\/HomeTimeline\/?$/;
      return ['https://x.com','https://api.x.com'].includes(u.origin) && route.test(u.pathname);
    } catch { return false; }
  };
  function ingest(obj) {
    if (!obj || typeof obj !== 'object') return;
    if (obj.promotedMetadata || obj.promoted_metadata || obj.entryId?.startsWith('promoted-')) return;
    const post = obj.legacy;
    if (obj.__typename === 'Tweet' && /^\d+$/.test(obj.rest_id) && post) {
      if(directId && obj.rest_id!==directId) return;
      const text=obj.note_tweet?.note_tweet_results?.result?.text || post.full_text || '';
      if(!directId && samples.size<100 && !post.retweeted_status_result && text.replace(/https?:\/\/\S+/g,'').trim()) samples.set(obj.rest_id,{id:obj.rest_id,text});
      if (!directId && (post.retweeted_status_result || post.favorited !== false || post.retweeted !== false)) return;
      const media = (post.extended_entities?.media || []).filter(m=>m.type==='video').map(m=>({
        key:m.id_str, poster:m.media_url_https, variants:m.video_info?.variants || []
      }));
      const likes=post.favorite_count;
      if (media.length || directId) rows.set(obj.rest_id,{id:obj.rest_id,text,media,likes});
      return;
    }
    for (const value of Object.values(obj)) ingest(value);
  }
  if(directId) window.__xpullDirectPost = () => rows.get(directId);
  else window.__xpullRecommended = (sample=false) => Array.from((sample?samples:rows).values());
  const originalOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method,url,...args) {
    if (isSearch(url)) this.addEventListener('load',()=>{
      try { accept(this.responseType==='json'?this.response:JSON.parse(this.responseText)); } catch {}
    },{once:true});
    return originalOpen.call(this,method,url,...args);
  };
  const originalFetch = window.fetch;
  window.fetch = async function(input,...args) {
    const response = await originalFetch.call(this,input,...args);
    if (isSearch(response.url)) response.clone().json().then(accept).catch(()=>{});
    return response;
  };
})();
