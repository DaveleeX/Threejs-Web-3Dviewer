function component(value,limit,fallback){
  const clean=String(value||'').normalize('NFKC').replace(/https?:\/\/\S+/gu,'')
    .replace(/[<>:"/\\|?*\p{C}]/gu,' ').replace(/\s+/g,' ').trim();
  const short=Array.from(clean).slice(0,limit).join('').replace(/^[. ]+|[. ]+$/g,'');
  return short && !/^(con|prn|aux|nul|com\d|lpt\d)(\.|$)/i.test(short)?short:fallback;
}

export function archiveFolder(owner,id,category,title){
  if(!/^\w{1,15}$/.test(owner)||!/^\d{1,20}$/.test(id)) throw Error('无效的归档账号或帖子 ID');
  const label=component(category==='3D 建模与渲染'?'模型渲染':category,18,'其他').replace(/类$/,'')+'类';
  return 'Xpull/@'+owner+'/'+label+'/'+component(title,36,'未命名笔记')+' ['+id+']/';
}

export function archivedId(filename,owner){
  const parts=filename.replaceAll('\\','/').split('/');
  const i=parts.lastIndexOf('Xpull');
  if(i<0 || parts[i+1]?.toLowerCase()!=='@'+owner.toLowerCase()) return;
  const leaf=parts.at(-2);
  if(parts.length-i===4 && /^\d+$/.test(leaf)) return leaf;
  if(parts.length-i===5) return leaf.match(/ \[(\d+)\]$/)?.[1];
}
