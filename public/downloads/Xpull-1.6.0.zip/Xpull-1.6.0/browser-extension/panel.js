import {selectVideo, recentSample} from './matching.mjs';
import {buildProfile, describeProfile, discoverHomeTopics, matchProfile} from './profile.mjs';
import {analyzeFile,readLinkFile} from './social.mjs';
import {archiveFolder, archivedId} from './archive.mjs';

const el = id => document.getElementById(id);
const pause = ms => new Promise(resolve=>setTimeout(resolve,ms));
const status = message => { el('status').textContent = message; };
function workflow(step){
  document.querySelectorAll('[data-step]').forEach(node=>{
    node.classList.toggle('active',node.dataset.step===step);
  });
}

async function inspect(tabId,func,world='ISOLATED') {
  const [frame] = await chrome.scripting.executeScript({target:{tabId},world,func});
  return frame.result;
}

function readTimeline() {
  const profile = document.querySelector('[data-testid="AppTabBar_Profile_Link"]');
  const username = profile?.pathname?.match(/^\/(\w{1,15})\/?$/)?.[1];
  const posts = [];
  for(const article of document.querySelectorAll('article[data-testid="tweet"]')) {
    const url = article.querySelector('time')?.closest('a')?.pathname;
    const id = url?.match(/\/status\/(\d+)/)?.[1];
    if(!id) continue;
    const text = article.querySelector('[data-testid="tweetText"]')?.innerText || '';
    const hashtags = [...text.matchAll(/#([\p{L}\p{N}_]+)/gu)].map(m=>({tag:m[1]}));
    posts.push({id,text,liked:!!article.querySelector('[data-testid="unlike"]'),reposted:!!article.querySelector('[data-testid="unretweet"]'),entities:{hashtags}});
  }
  return {username,posts,pathname:location.pathname,empty:!!document.querySelector('[data-testid="emptyState"]')};
}

function analysisProgress(label,value,max){
  workflow('profile');
  el('analysisActivity').hidden=false;
  el('analysisStage').textContent=label;
  const bar=el('analysisBar');
  if(value==null) bar.removeAttribute('value');
  else {bar.max=max;bar.value=value;}
}

async function sample(tabId,owner,source,limit,existing) {
  const seeds = existing || new Map();
  const route=existing?'/'+owner:source==='bookmarks'?'/i/bookmarks':'/'+owner+'/'+source;
  await chrome.tabs.update(tabId,{url:'https://x.com'+route+'#xpull-'+source});
  let idle = 0, installed=false;
  for(let step=0;step<70 && seeds.size<limit;step++) {
    await pause(900);
    const page = await inspect(tabId,readTimeline);
    if(/login|flow/.test(page.pathname)) throw Error('请在打开的 X 标签页完成登录或验证，然后回采集台重试。');
    if(!page.username) continue;
    const historyLikes=source==='likes' && ['/i/history','/i/likes'].includes(page.pathname);
    if(page.pathname.toLowerCase()!==route.toLowerCase() && !historyLikes) continue;
    if(owner && owner!==page.username) throw Error('账号已切换，请重新采集。');
    const previous = seeds.size;
    if(!installed){
      await chrome.scripting.executeScript({target:{tabId},world:'MAIN',func:s=>{window.__xpullSampleSource=s;},args:[source]});
      await chrome.scripting.executeScript({target:{tabId},world:'MAIN',files:['sample-data.js']});
      installed=true;
    }
    const batch=await inspect(tabId,()=>window.__xpullSampleRows?.() || [],'MAIN');
    const visible=existing?page.posts.filter(post=>post.reposted):page.posts;
    for(const post of [...batch,...visible]) if(seeds.size<limit && post.text.replace(/https?:\/\/\S+/g,'').trim() && (!historyLikes || post.liked)) seeds.set(post.id,post);
    analysisProgress('正在分析'+({likes:'点赞',reposts:'转帖',bookmarks:'收藏'})[source]+'样本 · '+seeds.size+' / '+limit,seeds.size,limit);
    if((page.empty && !page.posts.length) || seeds.size>=limit) break;
    idle = seeds.size===previous ? idle+1 : 0;
    if(idle>=18) break;
    await inspect(tabId,()=>{
      const posts=document.querySelectorAll('article[data-testid="tweet"]');
      posts[posts.length-1]?.scrollIntoView({block:'end',behavior:'instant'});
      window.scrollBy(0,window.innerHeight*.8);
    });
  }
  return seeds;
}

async function* homeBatches(tabId,owner,sampling=false) {
  let ready=false, installed=false;
  for(let step=0;step<(sampling?40:120);step++) {
    await pause(1000);
    const page=await inspect(tabId,()=>{
      const username=document.querySelector('[data-testid="AppTabBar_Profile_Link"]')?.pathname?.slice(1);
      if(location.pathname!=='/home') return {};
      const tabs=[...document.querySelectorAll('[role="tab"],[role="tablist"] a')];
      const tab=tabs.find(t=>/for\s*you|为[你您]推荐|為[你您]推薦|推荐|推薦/i.test(t.innerText || t.getAttribute('aria-label') || ''));
      const active=tab?.getAttribute('aria-selected');
      if(tab && active==='false'){tab.click();return {username,switching:true};}
      const hooked=typeof window.__xpullRecommended==='function';
      window.__xpullActiveRun=true;
      return {username,hooked,ready:hooked && (active==='true' || window.__xpullFeedPages?.()>0),labels:tabs.map(t=>t.innerText).join(' / ')};
    },'MAIN');
    if(!page.username) continue;
    if(page.username!==owner) throw Error('账号已切换，请重新采集。');
    if(page.switching) continue;
    if(!page.hooked && !installed){
      await chrome.scripting.executeScript({target:{tabId},world:'MAIN',files:['recommendations.js']});
      installed=true;
      continue;
    }
    if(!page.ready){
      if(step>30) throw Error(page.hooked?'首页脚本已连接，但没有识别到推荐数据。页面标签：'+(page.labels || '无'):'首页脚本未加载，请检查 Xpull 对 x.com 的站点访问权限。');
      if(step>3 && step%3===0) await inspect(tabId,()=>window.scrollBy(0,window.innerHeight));
      continue;
    }
    ready=true;
    const [{result}]=await chrome.scripting.executeScript({target:{tabId},world:'MAIN',func:sample=>window.__xpullRecommended?.(sample)||[],args:[sampling]});
    yield result;
    await inspect(tabId,()=>window.scrollBy(0,window.innerHeight*1.8));
  }
  if(!ready) throw Error('未能验证登录账号和推荐栏。');
}

async function recommendations(tabId,profile,excluded,count,owner,summary,focus,minLikes) {
  const candidates=new Map();
  for await(const rows of homeBatches(tabId,owner)){
    for(const row of rows){
      if(!Number.isSafeInteger(row.likes) || row.likes<minLikes){
        candidates.delete(row.id);
        continue;
      }
      if(excluded.has(row.id) || !row.media.some(selectVideo)) continue;
      const match=matchProfile(profile,row.text,focus);
      if(match.score) candidates.set(row.id,{...row,...match,focus,minLikes});
    }
    status(summary+'。正在浏览「为你推荐」：已匹配 '+candidates.size+' 条至少 '+minLikes+' 赞的候选。');
    if(candidates.size>=Math.max(12,count*3)) break;
  }
  return [...candidates.values()].sort((a,b)=>b.score-a.score || b.likes-a.likes);
}

async function download(url,filename) {
  const id=await chrome.downloads.download({url,filename,saveAs:false,conflictAction:'overwrite'});
  for(;;) {
    const [item]=await chrome.downloads.search({id});
    if(item?.state==='complete') return id;
    if(!item || item.state==='interrupted') throw Error(item?.error || '下载已中断');
    if(filename.endsWith('.mp4')){
      const percent=item.totalBytes>0?' '+Math.floor(100*item.bytesReceived/item.totalBytes)+'%':'';
      status('正在下载视频'+percent+'。原帖文本已保存，下载完成后自动写入口播。');
    }
    await pause(600);
  }
}

async function writeAigx(job) {
  const [video]=await chrome.downloads.search({id:job.videoId});
  const [note]=await chrome.downloads.search({id:job.noteId});
  if(!video?.filename || !note?.filename) throw Error('未找到视频或 source.txt 的下载记录。');
  const result=await chrome.runtime.sendNativeMessage('studio.aigx.xpull',{video:video.filename,note:note.filename});
  if(!result?.ok) throw Error(result?.message || '本机写作服务未返回结果');
  localStorage.removeItem('aigx:'+job.videoId);
}

function pendingJobs(){
  return Object.keys(localStorage).filter(k=>k.startsWith('aigx:')).map(k=>JSON.parse(localStorage.getItem(k)));
}
function updatePending(){
  const n=pendingJobs().length;
  el('retry').hidden=!n;
  el('retry').textContent='补写待处理文案（'+n+'）';
}
el('retry').onclick=async()=>{
  el('retry').disabled=true;
  try{
    for(const job of pendingJobs()){
      status('正在重新生成 '+job.post+' 的笔记和口播…');
      await writeAigx(job);
    }
    status('待处理文案已写入对应的 source.txt。');
  }catch(e){status('补写失败：'+e.message);}finally{updatePending();el('retry').disabled=false;}
};
updatePending();

function videoCard(row,media=row.media.find(selectVideo)) {
  const card=document.createElement('article');
  const link=document.createElement('a');
  link.href='https://x.com/i/status/'+row.id; link.target='_blank'; link.rel='noopener'; link.title='查看原帖';
  const variant=media && selectVideo(media);
  function showFrame(){
    if(!variant){link.textContent='画面暂缺';return;}
    const video=document.createElement('video');
    video.muted=true; video.preload='metadata'; video.src=variant.url+'#t=0.1';
    video.onerror=()=>{link.textContent='画面暂缺';};
    link.replaceChildren(video);
  }
  if(media?.poster?.startsWith('https://pbs.twimg.com/')){
    const img=document.createElement('img'); img.alt='原帖视频画面'; img.onerror=showFrame; img.src=media.poster; link.append(img);
  }else showFrame();
  const category=row.category || describeProfile(buildProfile([row]))[0] || '其他';
  const info=document.createElement('div');
  info.textContent=(Number.isSafeInteger(row.likes)?row.likes.toLocaleString()+' 赞':'点赞数未知')+' · '+category;
  card.append(link,info); return card;
}

function reviewBatch(rows,count){
  workflow('preview');
  const cards=el('cards'); cards.replaceChildren();
  const checks=rows.map(row=>{
    const card=videoCard(row);
    const label=document.createElement('label');
    const check=document.createElement('input'); check.type='checkbox'; check.checked=true;
    label.append(check,' 保留'); card.append(label); cards.append(card); return check;
  });
  const selected=()=>rows.filter((_,i)=>checks[i].checked);
  function refresh(){
    const n=selected().length;
    el('confirm').textContent='确认下载（'+n+'）'; el('confirm').disabled=!n;
    el('replace').disabled=n===count;
  }
  cards.onchange=refresh; refresh(); el('review').hidden=false;
  return new Promise(resolve=>{
    for(const action of ['replace','swap','confirm','cancel']){
      el(action).onclick=()=>{
        el('review').hidden=true;
        resolve({action,kept:action==='swap'?[]:selected()});
      };
    }
  });
}

async function save(row,owner) {
  workflow('archive');
  const category=row.category || describeProfile(buildProfile([row]))[0];
  status('正在为笔记生成归档短标题…');
  const naming=await chrome.runtime.sendNativeMessage('studio.aigx.xpull',{action:'title',text:row.text.slice(0,2000)}).catch(()=>null);
  const folder=archiveFolder(owner,row.id,category,naming?.title || row.text.trim().split(/[\n。！？]/u)[0]);
  const source='https://x.com/i/status/'+row.id;
  let saved=0;
  const reason=row.direct ? '来源：粘贴原帖链接' : '首页推荐 · 匹配 '+row.reasons.join('、')+'\n本次倾向：'+(row.focus || '综合画像')+'\n采集时点赞数：'+row.likes+'（本次门槛 '+row.minLikes+'）';
  const note=URL.createObjectURL(new Blob([source+'\n'+row.text+'\n\n'+reason+'\n'],{type:'text/plain;charset=utf-8'}));
  let noteId;
  try {noteId=await download(note,folder+'source.txt');}finally{URL.revokeObjectURL(note);}
  for(const [idx,media] of row.media.entries()) {
    try {
      const variant=selectVideo(media);
      if(!variant) throw Error('没有可下载的 MP4');
      const id=await download(variant.url,folder+'video-'+(idx+1)+'.mp4');
      const card=videoCard(row,media);
      el('list').append(card); saved++;
      const job={videoId:id,noteId,post:row.id};
      localStorage.setItem('aigx:'+id,JSON.stringify(job));
      status('视频已保存，AIGX 正在看画面并撰写笔记和口播…');
      try{await writeAigx(job);}catch(e){
        if(row.direct) throw Error('视频已保存，小红书文案尚未写入。请点「补写待处理文案」。原因：'+e.message);
        status('视频已保存，文案待补写：'+e.message);
      }
      updatePending();
      break;
    } catch(e){if(saved && row.direct){updatePending();throw e;}if(e.message==='USER_CANCELED') throw Error('你已取消下载，本次任务已停止。');status('视频 '+(idx+1)+'：'+e.message);}
  }
  return saved;
}

function parsePostLink(input){
  let url;
  try{url=new URL(input.trim());}catch{}
  const match=url?.pathname.match(/^\/(\w{1,15}|i\/web)\/status\/(\d{1,20})(?:\/(?:video|photo)\/\d+)?\/?$/);
  if(!match || !['https:','http:'].includes(url.protocol) || !/^(?:(?:www|mobile|m)\.)?(?:x|twitter)\.com$/i.test(url.hostname)){
    throw Error('请输入含 /status/ 和帖子编号的 X 原帖链接。');
  }
  return {id:match[2],url:'https://x.com/'+match[1]+'/status/'+match[2]+'#xpull-post'};
}

function fileLinks(text){
  const unique=new Map();
  const pattern=/(?<![\w./@-])(?:https?:\/\/)?(?:(?:www|mobile|m)\.)?(?:x|twitter)\.com\/(?:\w{1,15}|i\/web)\/status\/\d{1,20}(?![\w])/gi;
  for(const [raw] of text.matchAll(pattern)){
    const link=parsePostLink(/^https?:/i.test(raw)?raw:'https://'+raw);
    if(!unique.has(link.id)) unique.set(link.id,link);
  }
  return [...unique.values()];
}

async function downloadPost(link){
  workflow('archive');
  let tabId;
  try{
    status('正在打开指定原帖…');
    const tab=await chrome.tabs.create({url:link.url,active:true});
    tabId=tab.id;
    let restarted=false;
    for(let i=0;i<55;i++){
      await pause(800);
      const page=await inspect(tabId,()=>({
        path:location.pathname,owner:document.querySelector('[data-testid="AppTabBar_Profile_Link"]')?.pathname?.slice(1),
        attached:typeof window.__xpullDirectPost==='function',row:window.__xpullDirectPost?.()
      }),'MAIN');
      if(/\/login|\/flow\//.test(page.path)) throw Error('请在 Chrome 登录 X 后重试。');
      if(!page.path.endsWith('/status/'+link.id)) continue;
      if(page.owner && !page.attached && !restarted){
        await chrome.tabs.update(tabId,{url:'https://x.com'+page.path+'#xpull-post'});
        await chrome.tabs.reload(tabId); restarted=true;continue;
      }
      if(!/^\w{1,15}$/.test(page.owner||'') || page.row?.id!==link.id) continue;
      await chrome.tabs.remove(tabId); tabId=undefined;
      const files=await chrome.downloads.search({state:'complete',query:[link.id],limit:0});
      const archived=files.filter(f=>archivedId(f.filename,page.owner)===link.id);
      const video=archived.find(f=>/video-\d+\.mp4$/.test(f.filename));
      const note=video && archived.find(f=>f.filename===video.filename.replace(/video-\d+\.mp4$/,'source.txt'));
      const relocated=video && note && (!video.exists || !note.exists) && await chrome.runtime.sendNativeMessage('studio.aigx.xpull',{action:'locate',video:video.filename,note:note.filename}).catch(()=>null);
      if(video && note && ((video.exists && note.exists) || relocated?.ok)){
        const job={videoId:video.id,noteId:note.id,post:link.id};
        localStorage.setItem('aigx:'+video.id,JSON.stringify(job));
        status('已找到本地视频，正在检查并补写小红书笔记和口播…');
        try{await writeAigx(job);}finally{updatePending();}
        return '已核对本地归档，source.txt 中已有小红书笔记和口播。';
      }
      const n=await save({...page.row,direct:true},page.owner);
      return n?'原帖视频已保存，小红书笔记和约 25 秒口播已写入本帖的 source.txt。':'本次只保存了原帖正文，未下载到视频，未生成小红书文案。';
    }
    throw Error('未读到指定原帖。请确认当前账号能查看该帖，并已重新加载 Xpull。');
  }finally{
    if(tabId!==undefined) await chrome.tabs.remove(tabId).catch(()=>{});
  }
}

async function submitDownload(event){
  event.preventDefault();
  if(el('directBtn').disabled) return;
  const batch=event.currentTarget.id==='batch';
  const controls=['run','directBtn','batchBtn','batchFile'].map(el);
  controls.forEach(c=>c.disabled=true);
  try{
    if(!batch){status(await downloadPost(parsePostLink(el('postUrl').value)));return;}
    el('batchResults').replaceChildren(); el('batchProgress').textContent='正在识别文件中的原帖链接…';
    const links=fileLinks(await readLinkFile(el('batchFile').files[0]));
    if(!links.length) throw Error('文件中未找到含 /status/ 和帖子编号的 X 链接。');
    let failed=0, processed=0;
    for(const link of links){
      el('batchProgress').textContent='正在处理 '+(processed+1)+' / '+links.length+' 条';
      const item=document.createElement('li'), anchor=document.createElement('a');
      anchor.href=link.url; anchor.target='_blank'; anchor.rel='noopener'; anchor.textContent=link.id;
      item.append(anchor); el('batchResults').append(item);
      try{item.append(' · '+await downloadPost(link));}
      catch(e){failed++;item.append(' · '+e.message);if(e.message.includes('已取消下载')){processed++;break;}}
      processed++;
    }
    el('batchProgress').textContent='已处理 '+processed+' / '+links.length+' 条，其中 '+failed+' 条出错。';
    status('批量任务已结束，请查看逐条结果。');
  }catch(e){if(batch) el('batchProgress').textContent=e.message;status(e.message);}
  finally{controls.forEach(c=>c.disabled=false);}
}
el('direct').onsubmit=submitDownload;
el('batch').onsubmit=submitDownload;

let selectedAnalysis;
el('socialFile').onchange=async()=>{
  const file=el('socialFile').files[0];
  el('clearUpload').hidden=!file;
  el('uploadPreview').textContent=file?'正在分析…':'';
  selectedAnalysis=file?analyzeFile(file).then(data=>({data}),error=>({error})):null;
  const result=await selectedAnalysis;
  if(!file || el('socialFile').files[0]!==file) return;
  el('uploadPreview').textContent=result.error?result.error.message:result.data.method+'取 '+result.data.posts.length+' 条：'+result.data.posts.map(p=>p.title||p.category).join('、');
};
el('clearUpload').onclick=()=>{
  el('socialFile').value=''; el('socialFile').onchange();
};
el('run').onclick=async()=>{
  el('batchBtn').disabled=true;
  el('directBtn').disabled=true;
  el('run').disabled=true; el('list').replaceChildren();
  el('sources').disabled=true;
  el('socialFile').disabled=true;
  el('clearUpload').disabled=true;
  el('profile').textContent='';
  let tabId;
  try {
    analysisProgress(selectedAnalysis?'正在核对上传数据…':'正在准备画像分析…');
    const analysis=await selectedAnalysis;
    if(analysis?.error) throw Error('上传数据无法用于画像：'+analysis.error.message+'。可移除文件后按默认方式分析。');
    const upload=analysis?.data;
    analysisProgress('正在识别当前登录的 X 账号…');
    status('正在分析账号画像，请保持采集台打开。');
    const tab=await chrome.tabs.create({url:'https://x.com/home',active:true});
    tabId=tab.id;
    let owner;
    for(let i=0;i<26 && !owner;i++){
      await pause(900);
      const page=await inspect(tabId,readTimeline);
      if(/login|flow/.test(page.pathname)) throw Error('请完成 X 登录后重试。');
      owner=page.username;
    }
    if(!owner) throw Error('未识别到 X 账号，请检查登录状态。');
    const sources=el('sources').value.split(',');
    const names={likes:'点赞',reposts:'转帖',bookmarks:'收藏'};
    const feeds=[], counts=[];
    for(const source of sources){
      analysisProgress('正在打开'+names[source]+'时间线…');
      const batch=await sample(tabId,owner,source,20);
      if(source==='reposts' && batch.size<20) await sample(tabId,owner,source,20,batch);
      counts.push(names[source]+'读取 '+batch.size+' 条');
      feeds.push([...batch.values()]);
    }
    const seeds=recentSample(feeds);
    const summary=counts.join('、')+'，本次采用 '+seeds.size+'/20 条不同的帖子';
    if(seeds.size<20) throw Error(summary+'。画像需要至少 20 条有正文的不同帖子，本次已停止。');
    const excluded=new Set(feeds.flat().map(p=>p.id));
    await chrome.tabs.update(tabId,{url:'https://x.com/home#xpull'});
    analysisProgress('正在连接首页「为你推荐」…');
    const home=new Map();
    for await(const rows of homeBatches(tabId,owner,true)){
      for(const row of rows){
        if(!excluded.has(row.id)) home.set(row.id,row);
        if(home.size===10) break;
      }
      analysisProgress('正在分析首页推荐样本 · '+home.size+' / 10',home.size,10);
      if(home.size===10) break;
    }
    if(!home.size) throw Error('未读取到不同于互动记录的首页推荐样本，请确认「为你推荐」可打开后重试。');
    for(const id of home.keys()) excluded.add(id);
    const profile=buildProfile([...seeds.values(),...home.values(),...(upload?.posts||[]).map(p=>({...p,reference:true}))]);
    profile.homeTopics=discoverHomeTopics([...home.values()]);
    el('profile').textContent='账号画像 · '+(describeProfile(profile).join('、') || '综合兴趣')+'。互动 '+seeds.size+' 篇，首页 '+home.size+' 篇，上传 '+(upload?.posts.length||0)+' 条。';
    await chrome.tabs.remove(tabId); tabId=null;
    const choices=el('focus');
    choices.replaceChildren(new Option('综合画像',''));
    const current=document.createElement('optgroup');
    current.label='本轮首页主题';
    for(const [name,topic] of profile.homeTopics){
      current.append(new Option(name+'（首页 '+topic.count+' 篇）',name));
    }
    if(current.children.length) choices.append(current);
    const combined=document.createElement('optgroup');
    combined.label='综合画像分类';
    for(const [term] of [...profile.categories].sort((a,b)=>b[1]-a[1])){
      if(profile.homeTopics.has(term)) continue;
      const n=profile.categories.get(term) || profile.frequencies.get(term);
      combined.append(new Option(term+'（权重 '+n+'）',term));
    }
    if(combined.children.length) choices.append(combined);
    analysisProgress('画像分析完成',1,1);
    el('selection').hidden=false;
    workflow('preview');
    status('请选择倾向、点赞门槛和每批预览数量。');
    await new Promise(resolve=>el('start').addEventListener('click',resolve,{once:true}));
    const focus=choices.value;
    el('analysisActivity').hidden=true;
    const minLikes=Number(el('minLikes').value);
    el('selection').hidden=true;
    const prior=await chrome.downloads.search({state:'complete',filenameRegex:'[.]mp4$',limit:0});
    for(const item of prior){
      const id=archivedId(item.filename,owner);
      if(id) excluded.add(id);
    }
    const count=Number(el('count').value);
    const panel=await chrome.tabs.getCurrent();
    const feedTab=await chrome.tabs.create({url:'https://x.com/home#xpull',active:true});
    tabId=feedTab.id;
    let rows=[], reserve=[];
    while(true){
      const needed=count-rows.length;
      if(reserve.length<needed){
        await chrome.tabs.update(tabId,{active:true});
        const more=await recommendations(tabId,profile,excluded,needed-reserve.length,owner,summary,focus,minLikes);
        for(const row of more) excluded.add(row.id);
        reserve.push(...more);
      }
      rows.push(...reserve.splice(0,needed));
      if(panel) await chrome.tabs.update(panel.id,{active:true});
      status('本次倾向 · '+(focus || '综合画像')+'，至少 '+minLikes+' 赞。当前候选 '+rows.length+' / '+count+' 条。');
      const {action,kept}=await reviewBatch(rows,count);
      if(action==='cancel'){status('本次任务已取消。');return;}
      rows=kept;
      if(action==='confirm') break;
    }
    await chrome.tabs.remove(tabId); tabId=null;
    let files=0;
    for(const [idx,row] of rows.entries()){
      status('正在保存已确认的第 '+(idx+1)+' / '+rows.length+' 条。');
      files+=await save(row,owner);
    }
    status('已确认 '+rows.length+' 条，成功下载 '+files+' 个视频。'+(pendingJobs().length?'还有 '+pendingJobs().length+' 篇文案待补写。':''));
  }catch(e){status(e.message);}finally{
    el('analysisActivity').hidden=true;
    if(tabId!=null) await chrome.tabs.remove(tabId).catch(()=>{});
    el('cards').replaceChildren(); el('review').hidden=true; el('selection').hidden=true;
    el('batchBtn').disabled=false;el('socialFile').disabled=false;el('clearUpload').disabled=false;el('sources').disabled=false;el('run').disabled=false;el('directBtn').disabled=false;
  }
};
