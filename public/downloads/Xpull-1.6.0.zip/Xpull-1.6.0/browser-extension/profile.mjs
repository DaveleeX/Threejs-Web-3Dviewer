// Domain aliases connect related Chinese and English descriptions. Other topics
// are learned directly from the account's sample, without a fixed category list.
const domains = {
  '3D 建模与渲染': /\b(?:3d|blender|three\.?js|tripo(?:ai)?|meshes|gltf|gaussian splatting|unreal engine|rendering)\b|三维|建模|渲染/iu,
  '动画与动捕': /\b(?:animat(?:e|es|ed|ion|ions|or)|mocap|rigging|keyframes?|motion capture|mmd)\b|动画|动捕|动作捕捉|骨骼绑定/iu,
  '交互游戏': /\b(?:games?|gameplay|webcam|gestures?|hand tracking|gamepad)\b|手势|体感|游戏/iu,
  'AI 视频': /\b(?:seedance|kling|veo|text.to.video|image.to.video|video generation|ai[- ](?:generated[- ])?videos?)\b|图生视频|文生视频|可灵|AI\s*视频/iu,
  '4D 高斯': /\b(?:4dgs|4d[- ]?gaussians?|4d[- ]?(?:gaussian[- ])?splatting|dynamic gaussian(?:s| splatting)?)\b|4D\s*高斯|动态高斯/iu,
  '编程工具': /\b(?:claude code|codex|coding agent|vibe coding|cursor ide)\b|编程助手|代码生成/iu
};
const stop = new Set('about after again all also and any are around back been best but can check could day demo did does down even every first for free from get give good great had has have here how into its just know like made make many more most much new next now one only open our out over post really see share she should show some still than that the their them then there these they thing think this those through time today too use used using very via want was watch way well were what when where which who why will with work would you your ai video videos 一个 一些 这个 这些 那个 他们 我们 你们 可以 通过 已经 还是 真的 现在 自己 进行 大家 视频 分享'.split(' '));
const seg = new Intl.Segmenter('zh',{granularity:'word'});
for(const word of 'am an as at be by do he if in is it me my no of oh ok on or so to up us we yes im its his her our all got two any why lol look looking today did does done let lets set part take took put try also able going goes making getting using used being doing awesome amazing check post link full click thank thanks please 还有 什么 这样 这种 一起 就能 看到 不是 没有 但是 以及 其中 非常 效果 看看'.split(' ')) stop.add(word);
function features(text) {
  const clean=text.toLowerCase().replace(/https?:\/\/\S+/gu,' ');
  const terms=new Set();
  for(const {segment,isWordLike} of seg.segment(clean)){
    if(isWordLike && /^[\p{L}\d][\p{L}\d_]{1,30}$/u.test(segment) && !/^\d+$/.test(segment) && !stop.has(segment)) terms.add(segment);
  }
  const categories=Object.entries(domains).filter(([name,pattern])=>clean.includes(name.toLowerCase()) || pattern.test(clean)).map(([name])=>name);
  return {terms,categories};
}
export function buildProfile(posts){
  const labels=new Set();
  const examples=posts.map(post=>{
    const example=features(post.text);
    example.weight=post.reference?2:1;
    const label=post.category?.trim();
    if(label && label.length<=32 && !features(label).categories.length){
      labels.add(label);
      example.categories.push(label);
    }
    return example;
  });
  const frequencies=new Map(), categories=new Map(), referenceCategories=new Set();
  for(const example of examples){
    for(const term of example.terms) frequencies.set(term,(frequencies.get(term)||0)+example.weight);
    for(const category of example.categories) categories.set(category,(categories.get(category)||0)+example.weight);
    if(example.weight>1) example.categories.forEach(category=>referenceCategories.add(category));
  }
  return {examples,frequencies,categories,labels,referenceCategories};
}
export function describeProfile(profile){
  const ranked=entries=>[...entries].sort((a,b)=>b[1]-a[1]).map(([name])=>name);
  return ranked(profile.categories).slice(0,4);
}

// Translate common feed topics; unfamiliar hashtags and recurring terms can
// still become directions without an entry in this dictionary.
const topicNames=[
  ['机器人',['robot','robots','robotics','机器人']],
  ['摄影',['photography','photographer','摄影']],
  ['建筑设计',['architecture','architectural','建筑设计','建筑']],
  ['天文观测',['astronomy','astrophotography','天文','星空摄影']],
  ['声音设计',['sound design','sounddesign','声音设计','音效设计']],
  ['动作生成',['motion generation','动作生成']],
  ['数字人',['digital human','digital humans','数字人']],
  ['点云重建',['point cloud','point clouds','pointcloud','点云']],
  ['程序化生成',['procedural generation','proceduralgeneration','程序化生成']]
];
const generic=new Set('whole step real opus claude model models game games tool tools today latest release released version update project projects built building created people amazing world working something things think great really finally doing better because first going author original 分享 今天 作品 内容 工具 发布 一个 方法 模型 开始 使用 效果 展示 实现 学习'.split(' '));
function topicText(text){
  return ' '+text.normalize('NFKC').toLowerCase().replace(/https?:\/\/\S+|@[\w_]+/gu,' ').replace(/[^\p{L}\p{N}]+/gu,' ').trim()+' ';
}
function mentionsTopic(text,alias){
  return /\p{Script=Han}/u.test(alias)?text.includes(alias):text.includes(' '+alias+' ');
}
export function discoverHomeTopics(posts){
  const samples=posts.map(p=>topicText(p.text));
  const topics=new Map();
  function add(name,aliases,minCount,priority){
    const count=samples.filter(s=>aliases.some(a=>mentionsTopic(s,a))).length;
    if(count>=minCount && !topics.has(name)) topics.set(name,{aliases,count,priority});
  }
  for(const [name,aliases] of topicNames) add(name,aliases,1,2);
  const known=new Set(topicNames.flatMap(([name,aliases])=>[name,...aliases]));
  function eligible(word){
    return !known.has(word) && !stop.has(word) && !generic.has(word) && !features(word).categories.length &&
      /\p{L}/u.test(word) && word.length<=24;
  }
  for(const post of posts){
    for(const [,tag] of post.text.replace(/https?:\/\/\S+/gu,'').matchAll(/[#＃]([\p{L}\p{N}_]{2,24})/gu)){
      const alias=topicText(tag).trim();
      if(eligible(alias)) add(tag,[alias],1,1);
    }
    for(const term of features(post.text.replace(/@[\w_]+/gu,'')).terms){
      if(eligible(term) && (/\p{Script=Han}/u.test(term) || term.length>=5)) add(term,[term],2,0);
    }
  }
  const unique=new Map(), used=new Set();
  for(const [name,topic] of [...topics].sort((a,b)=>b[1].count-a[1].count || b[1].priority-a[1].priority)){
    if(topic.aliases.some(a=>used.has(a))) continue;
    unique.set(name,topic); topic.aliases.forEach(a=>used.add(a));
    if(unique.size===6) break;
  }
  return unique;
}
export function matchProfile(profile,text,focus=''){
  const candidate=features(text), hits=[];
  for(const label of profile.labels||[]){
    if(text.toLowerCase().includes(label.toLowerCase())) candidate.categories.push(label);
  }
  const normalized=topicText(text);
  const topical=[];
  for(const [name,topic] of profile.homeTopics||[]){
    if(topic.aliases.some(alias=>mentionsTopic(normalized,alias))) topical.push(name);
  }
  candidate.categories.push(...topical);
  const focused=!!focus && (candidate.categories.includes(focus) || candidate.terms.has(focus));
  for(const category of candidate.categories) if(profile.categories.has(category)) hits.push(category);
  let best=0, terms=[];
  for(const example of profile.examples){
    const overlap=[...candidate.terms].filter(t=>example.terms.has(t));
    const score=overlap.reduce((n,t)=>n+1+Math.min(2,(profile.frequencies.get(t)-1)/3),0)*(example.weight||1);
    if(overlap.length>=2 && score>best){best=score;terms=overlap;}
  }
  const domainScore=hits.reduce((n,c)=>n+3+Math.min(4,profile.categories.get(c))+(profile.referenceCategories?.has(c)?3:0),0);
  return {score:(domainScore+best+topical.length*3)*(focused?1.5:1), category:(focused?focus:null)||topical[0]||hits[0], reasons:[...new Set([focused?focus:null,...topical,...hits,...terms.slice(0,4)].filter(Boolean))]};
}
