// Installed in the dedicated sampling tab. Keep only rows from this source.
(() => {
  const source=window.__xpullSampleSource || location.hash.match(/^#xpull-(likes|reposts|bookmarks)$/)?.[1];
  if(!source || window.__xpullSampleRows) return;
  const operations={likes:/^(Likes|UserLikes|LikesTimeline)$/,reposts:/^(UserReposts|UserRepostsTimeline|UserRetweets|UserTweets|UserTweetsAndReplies)$/,bookmarks:/^Bookmarks$/};
  if(!operations[source]) return;
  const rows=new Map();
  function isTimeline(url){
    try {
      const u=new URL(url,location.href);
      return ['https://x.com','https://api.x.com'].includes(u.origin) && operations[source].test(u.pathname.split('/').filter(Boolean).at(-1));
    }catch{return false;}
  }
  function visit(obj){
    if(!obj || typeof obj!=='object' || obj.promotedMetadata) return;
    if(obj.__typename==='Tweet'){
      const original=obj.legacy?.retweeted_status_result?.result;
      const post=original?.tweet || original || obj;
      const legacy=post.legacy;
      if(!legacy || (source==='reposts' && !original && !legacy.retweeted) || (source==='likes' && !legacy.favorited)) return;
      const text=post.note_tweet?.note_tweet_results?.result?.text || legacy.full_text || '';
      if(/^\d+$/.test(post.rest_id) && text) rows.set(post.rest_id,{id:post.rest_id,text,liked:!!legacy.favorited});
      return;
    }
    for(const child of Object.values(obj)) visit(child);
  }
  window.__xpullSampleRows=()=>Array.from(rows.values());
  const open=XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open=function(method,url,...args){
    if(isTimeline(url)) this.addEventListener('load',()=>{
      try{visit(this.responseType==='json'?this.response:JSON.parse(this.responseText));}catch{}
    },{once:true});
    return open.call(this,method,url,...args);
  };
  const fetchPage=window.fetch;
  window.fetch=async function(...args){
    const res=await fetchPage.apply(this,args);
    if(isTimeline(res.url)) res.clone().json().then(visit).catch(()=>{});
    return res;
  };
})();
